#!/bin/sh

$seconds=$1

echo Starting job for $seconds seconds
date
sleep $seconds
date
echo done
