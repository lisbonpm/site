This is a presentation that I made about Flickr-Tools to be delivered at the first tech meeting of the Lisbon Perlmongers group on November the 16th, 2005.

For the Flickr-Tools project see http://darcs.nunonunes.org/.
For the Lisbon Perlmongers group see http://lisbon.pm.org/.
