#!/bin/sh

echo Starting long job
date
sleep 10
date
echo done
