#!/bin/sh

echo Starting quick job
date
sleep 3
date
echo done
