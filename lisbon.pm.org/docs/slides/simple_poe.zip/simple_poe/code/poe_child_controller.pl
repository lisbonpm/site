#!/usr/bin/perl -w
#
#  poe_child_controller
#

use strict;
use POE;
use POE::Component::Server::TCP;
use POE::Component::Child;
use POE::Session;

my $port = 7878;

my %clients;
my %process;

my %valid_scripts = (
  'long_delay' => {
      path => '/Users/melo/projects/simple_poe/code/long_delay.sh',
  },
  'short_delay' => {
      path => '/Users/melo/projects/simple_poe/code/short_delay.sh',
  },
  'user_delay' => {
      path => '/Users/melo/projects/simple_poe/code/user_delay.sh',
  },
);

$| = 1;

##################
# Process manager

my $proc_manager = POE::Component::Child->new(
     events => {
         stdout => \&stdout_from_child,
         stderr => \&stderr_from_child,
         done   => \&done_from_child,
     },
);


########################################
# TCP server to receive client requests

POE::Component::Server::TCP->new(
    Port => $port,
  
    ClientConnected    => \&client_connected,
    ClientDisconnected => \&client_disconnected,
    ClientInput        => \&client_input,
    
    ClientShutdownOnError => 1,  
);


#######################
# Start the POE kernel

$poe_kernel->run;



########################
# TCP Client management

sub client_connected {
  my ($heap, $session, @args) = @_[ HEAP, SESSION, ARG0..$#_ ];
  
  my $id = $session->ID;
  $heap->{session_id} = $id;
  $clients{$id} = $heap;
  print "Client connected from $heap->{remote_ip}/$heap->{remote_port}\n";
}


sub client_disconnected {
  my ($session, $heap) = @_[ SESSION, HEAP ];
  
  delete $clients{$session->ID};
  print "Client disconnected from $heap->{remote_ip}/$heap->{remote_port}\n";
}


sub client_input {
  my ($heap, $input) = @_[ HEAP, ARG0 ];
  
  my $client = $heap->{client};
  
  my ($cmd, @args) = split(/\s+/, $input);
  
  if (!$cmd) {
    $client->put('ERROR invalid input');
    return;
  }
  
  if ($cmd eq 'start') {
    my $script = shift @args;
    
    if (!exists $valid_scripts{$script}) {
      $client->put('ERROR invalid script');
      return;
    }
    
    my $id = $proc_manager->run($valid_scripts{$script}{path}, @args);
    print "Started process $script with id $id\n";
    $process{$id} = { completed => 0, output => '' };
    
    $client->put("OK $id script started");
    return;
  }
  
  if ($cmd eq 'check') {
    my $id = shift @args;
    if (!$id || !exists $process{$id}) {
      $client->put('ERROR invalid process');
      return;
    }
    
    print "Checking version $id\n";
    my $proc = $process{$id};
    
    if ($proc->{completed}) {
      $client->put("OK+$id completed, output follows");
      $client->put($proc->{output});
      $client->put(".");
      $client->put("OK $id terminated");
      delete $process{$id};
    }
    else {
      $client->put("OK $id still running");
    }
    return;
  }
  
  if ($cmd eq 'quit') {
    $poe_kernel->yield('shutdown');
    return;
  }
  
  $client->put('ERROR invalid command');
}


##############
# Child events

sub stdout_from_child {
  my ($self, $args) = @_;
  
  my $id  = $args->{wheel};
  my $out = $args->{out};
  $process{$id}{output} .= "$out\n";
  
  print "$id: stdout\n";
}

sub stderr_from_child {
  my ($self, $args) = @_;
  
  print STDERR "STDERR ($args->{wheel}): $args->{out}";
}

sub done_from_child {
  my ($self) = @_;
  
  my $id = $self->wheelid;
  
  $process{$id}{completed} = 1;
  
  print "$id: completed\n";
}



















